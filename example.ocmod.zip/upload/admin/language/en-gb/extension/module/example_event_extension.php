<?php
// Heading
$_['heading_title']             				= 'Example Event Extension';